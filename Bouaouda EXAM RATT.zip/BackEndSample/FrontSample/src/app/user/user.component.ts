import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from "@angular/forms";
import {UserService} from "./user.service";
import { Evenement } from '../Shared/evenement.model';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  users: any;
  UserForm: FormGroup;

  constructor(public userService: UserService,
              public fb: FormBuilder) {
    this.UserForm = this.fb.group({
      date: new FormControl('')
      ,
      tache : new FormControl(''),
      lieu: new FormControl(''),
      debut: new FormControl(''),
      fin: new FormControl(''),
    })
  }

  ngOnInit(): void {
    this.showUsers()
  }

  addUser() {
    this.userService.addUser(this.UserForm.value).subscribe((data)=>{
      console.log(data);
    })
  }

  showUsers(){
    this.userService.getAllUsers().subscribe((data)=>{
      this.users = data;
      console.log(data);
    })
  }

  Delete(_id: any) {
    this.userService.delete(_id).subscribe((data)=>{
      console.log(_id)
      console.log("Deleted")
  })
  }
  onEdit(id: any,user: Evenement) {
    this.userService.ChangeEvent(id, user).subscribe((res: any) => {
      console.log(res);
      alert("changed Successfully");
      window.location.reload();
    },
      error => {
        console.log(error.error)
      }
    )
  }
  }


