export class Evenement {
    date: Date;
    tache: string;
    lieu: string;
    debut: string;
    fin: string;
}